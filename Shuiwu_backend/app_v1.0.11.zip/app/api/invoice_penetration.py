"""
发票穿透报告 API 路由
提供发票穿透第三方服务对接功能
"""
from typing import Optional

from fastapi import APIRouter, Depends, Request, Query

from app.schemas.invoice_penetration import (
    InvoiceAuthorizationRequest,
    InvoiceAuthorizationResponse,
    InvoiceGetReportRequest,
    InvoiceReportData,
    InvoiceReportResponse,
    InvoiceReportNotifyData,
)
from app.services.invoice_penetration import invoice_penetration_service
from app.utils.response import response
from app.utils.dependencies import require_current_user
from app.middleware.member_permission import require_member_features
from app.infra.logging_config import get_logger

logger = get_logger("app.api.invoice_penetration")

router = APIRouter(prefix="/api/invoice-penetration", tags=["发票穿透报告"])


@router.post(
    "/authorization",
    summary="获取授权链接",
    description="""
    发票穿透报告获取授权链接接口

    **功能说明：**
    - 获取税局账号授权的 H5 链接
    - 用户通过链接进行税局账号密码授权
    - 授权完成后自动生成发票穿透报告

    **会员权益要求：**
    - 功能权限：enable_invoice_penetration（套餐配置）
    - 配额要求：每次消耗1次发票穿透配额

    **所需参数：**
    - taxpayerId: 纳税人识别号（明文，后端自动处理加密）
    - companyName: 企业名称（明文，后端自动处理加密）
    - cburl: 授权完成回调页面
    - reportType: 报告类型，默认 1（发票穿透）
    - beginDate: 开始时间（例202309）
    - overDate: 结束时间（例202408）

    **返回信息：**
    - orderNo: 订单号（唯一标识）
    - initialUrl: 授权链接（H5链接）

    **注意：**
    - 报告数据只取近36个月
    - 开始时间和结束时间间隔为12个月
    - 打开授权链接后切勿重复授权
    """,
    responses={
        200: {
            "description": "获取成功",
            "content": {
                "application/json": {
                    "example": {
                        "code": 1,
                        "message": "获取授权链接成功",
                        "data": {
                            "orderNo": "unique_order_no",
                            "initialUrl": "https://example.com/authorize?..."
                        }
                    }
                }
            }
        }
    }
)
@require_member_features(
    privileges=["invoice_penetration"],
    quotas={"invoice_penetration": 1}
)
async def get_authorization_url(
    request: Request,
    request_data: InvoiceAuthorizationRequest,
    current_user: str = Depends(require_current_user)
):
    """获取授权链接"""
    try:
        logger.info(f"用户 {current_user} 请求获取发票穿透授权链接")

        # 获取配额检查结果
        quota_check = getattr(request.state, "member_quota_check", {})
        remaining = quota_check.get("remaining", -1)

        result = await invoice_penetration_service.get_authorization_url(
            taxpayer_id=request_data.taxpayer_id,
            company_name=request_data.company_name,
            cburl=request_data.cburl,
            report_type=request_data.report_type,
            begin_date=request_data.begin_date,
            over_date=request_data.over_date,
            report_logo=request_data.report_logo,
            watermark=request_data.watermark,
            cover_url=request_data.cover_url,
            is_anonymity=request_data.is_anonymity,
        )

        return response.success(
            message="获取授权链接成功",
            data=result
        )

    except Exception as e:
        logger.error(f"获取授权链接失败: {e}")
        return response.fail(message=f"获取授权链接失败: {str(e)}")


@router.get(
    "/report_data",
    summary="获取报告数据",
    description="""
    获取发票穿透报告数据接口

    **功能说明：**
    - 根据订单号获取已生成的发票穿透报告数据

    **所需参数：**
    - taxpayerId: 纳税人识别号（明文，后端自动处理加密）
    - companyName: 企业名称（明文，后端自动处理加密）
    - orderNo: 订单号
    - dataType: 数据类型（1-数据，2-报告url）

    **返回数据：**
    - invoiceFirmInfoAllMap: 企业基本信息
    - invoiceEnterpriseAllMap: 发票分析
    - invoiceFinancialAnalysisAllMap: 财务风险评估
    - invoiceTaxRiskAssessmentAllMap: 税务风险评估
    - invoiceIntegratedRiskAssessmentAllMap: 财税票综合风险评估

    **注意：**
    - 参与签名字段：thirdPartyId, taxpayerId, companyName, orderNo
    - 如选择 dataType=2，则直接返回 PDF 的 URL 链接
    """,
    responses={
        200: {
            "description": "获取成功",
            "content": {
                "application/json": {
                    "example": {
                        "code": 1,
                        "message": "获取报告数据成功",
                        "data": {
                            "invoiceFirmInfoAllMap": {},
                            "invoiceEnterpriseAllMap": {}
                        }
                    }
                }
            }
        }
    }
)
async def get_report_data(
    taxpayer_id: str = Query(..., alias="taxpayerId", description="纳税人识别号（明文）"),
    company_name: str = Query(..., alias="companyName", description="企业名称（明文）"),
    order_no: str = Query(..., alias="orderNo", description="订单号"),
    data_type: Optional[int] = Query(None, alias="dataType", description="数据类型：1-数据，2-报告url"),
    current_user: str = Depends(require_current_user)
):
    """获取报告数据"""
    try:
        logger.info(f"用户 {current_user} 请求获取发票穿透报告数据: {order_no}")

        result = await invoice_penetration_service.get_report_data(
            taxpayer_id=taxpayer_id,
            company_name=company_name,
            order_no=order_no,
            data_type=data_type
        )

        return response.success(
            message="获取报告数据成功",
            data=result
        )

    except Exception as e:
        logger.error(f"获取报告数据失败: {e}")
        return response.fail(message=f"获取报告数据失败: {str(e)}")


@router.post(
    "/notify/callback",
    summary="报告生成完成通知回调",
    description="""
    发票穿透报告生成完成通知接口（发票穿透服务主动调用）

    **功能说明：**
    - 发票穿透服务在报告生成完成后会主动调用此接口
    - 需要在发票穿透后台配置回调地址

    **回调参数：**
    - orderNo: 订单号
    - state: 成功状态（0-失败，1-成功）
    - reportType: 报告类型（1-发票穿透）

    **返回格式：**
    - code: 1：失败，0：成功
    - message: 状态信息

    **注意：**
    - 此接口需要公网可访问
    - 建议对回调进行验签
    """,
    responses={
        200: {
            "description": "处理成功",
            "content": {
                "application/json": {
                    "example": {
                        "code": "0",
                        "message": "success"
                    }
                }
            }
        }
    }
)
async def report_notify_callback(
    notify_data: InvoiceReportNotifyData,
    request: Request
):
    """报告生成完成通知回调"""
    try:
        logger.info(
            f"收到发票穿透报告生成完成通知: orderNo={notify_data.order_no}, "
            f"state={notify_data.state}, reportType={notify_data.report_type}"
        )

        # TODO: 验证签名（如果发票穿透服务提供签名）
        # sign = request.query_params.get('sign')
        # if sign:
        #     public_key = os.getenv('CHASHUIBAO_PUBLIC_KEY', '')
        #     from app.services.chashuibao.sm2_signature import ChashuibaoSignature
        #     is_valid = ChashuibaoSignature.verify(
        #         notify_data.dict(), sign, public_key
        #     )
        #     if not is_valid:
        #         logger.warning("回调签名验证失败")
        #         return {"code": "1", "message": "签名验证失败"}

        # TODO: 处理回调逻辑
        # 1. 根据 orderNo 查询本地订单记录
        # 2. 更新订单状态
        # 3. 通知用户报告已生成
        # 4. 如果 state=0（失败），记录失败原因

        logger.info(f"发票穿透报告生成完成通知处理成功: {notify_data.order_no}")

        return {"code": "0", "message": "success"}

    except Exception as e:
        logger.error(f"处理报告生成完成通知失败: {e}")
        return {"code": "1", "message": str(e)}


@router.get(
    "/config",
    summary="获取发票穿透配置信息",
    description="""
    获取发票穿透服务配置信息（用于调试）

    **返回信息：**
    - baseUrl: 发票穿透服务地址
    - thirdPartyId: 第三方 ID
    """,
    responses={
        200: {
            "description": "获取成功",
            "content": {
                "application/json": {
                    "example": {
                        "code": 1,
                        "message": "获取配置成功",
                        "data": {
                            "baseUrl": "https://testcsbplus.dianzuanmao.com",
                            "thirdPartyId": "your_token"
                        }
                    }
                }
            }
        }
    }
)
async def get_config(current_user: str = Depends(require_current_user)):
    """获取发票穿透配置信息"""
    try:
        return response.success(
            message="获取配置成功",
            data={
                "baseUrl": invoice_penetration_service.base_url,
                "thirdPartyId": invoice_penetration_service.third_party_id,
            }
        )
    except Exception as e:
        logger.error(f"获取配置失败: {e}")
        return response.fail(message=f"获取配置失败: {str(e)}")
