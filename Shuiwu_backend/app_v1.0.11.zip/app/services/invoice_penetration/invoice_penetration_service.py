"""
发票穿透报告服务
复用查税宝的基础设施（SM2签名、HTTP客户端等）
"""
import httpx
import os
from typing import Optional, Dict, Any
from app.infra.logging_config import get_logger
from dotenv import load_dotenv

# 确保环境变量已加载
load_dotenv()

logger = get_logger("app.services.invoice_penetration")


class InvoicePenetrationService:
    """发票穿透报告服务"""

    def __init__(self):
        """初始化服务"""
        # 从环境变量获取配置（复用查税宝的配置）
        self.base_url = os.getenv(
            'CHASHUIBAO_BASE_URL',
            'https://testcsbplus.dianzuanmao.com'
        )
        self.third_party_id = os.getenv('CHASHUIBAO_THIRD_PARTY_ID', '')
        self.timeout = 30

        # 设置 SM2 私钥（复用查税宝的签名工具）
        private_key = os.getenv('CHASHUIBAO_PRIVATE_KEY', '')
        if private_key:
            from app.services.chashuibao.sm2_signature import ChashuibaoSignature
            ChashuibaoSignature.set_private_key(private_key)
            logger.info(f"SM2 私钥已配置 (长度: {len(private_key)})")

        logger.info(f"发票穿透服务初始化完成，Base URL: {self.base_url}, ThirdPartyID: {self.third_party_id[:20]}...")

    async def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """发送 HTTP 请求

        Args:
            method: 请求方法（GET/POST）
            path: 请求路径
            params: URL 参数
            data: 请求体数据
            headers: 请求头

        Returns:
            响应数据

        Raises:
            Exception: 请求失败
        """
        url = f"{self.base_url}{path}"

        # 默认请求头
        default_headers = {
            'Content-Type': 'application/json',
        }
        if headers:
            default_headers.update(headers)

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                if method.upper() == 'GET':
                    response = await client.get(url, params=params, headers=default_headers)
                else:
                    response = await client.post(url, params=params, json=data, headers=default_headers)

                response.raise_for_status()
                return response.json()

            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP 请求失败: {e.response.status_code} - {e.response.text}")
                raise Exception(f"发票穿透 API 请求失败: {e.response.status_code}")
            except httpx.RequestError as e:
                logger.error(f"HTTP 请求异常: {e}")
                raise Exception(f"发票穿透 API 请求异常: {str(e)}")

    async def get_authorization_url(
        self,
        taxpayer_id: str,
        company_name: str,
        cburl: str,
        report_type: str = "1",
        begin_date: Optional[str] = None,
        over_date: Optional[str] = None,
        report_logo: Optional[str] = None,
        watermark: Optional[str] = None,
        cover_url: Optional[str] = None,
        is_anonymity: Optional[int] = None
    ) -> Dict[str, Any]:
        """获取授权链接

        Args:
            taxpayer_id: 纳税人识别号（明文）
            company_name: 企业名称（明文）
            cburl: 授权完成回调页面
            report_type: 报告类型，默认 1（发票穿透）
            begin_date: 开始时间（例202309）
            over_date: 结束时间（例202408）
            report_logo: 封面logo URL
            watermark: 水印 URL
            cover_url: 封面 URL
            is_anonymity: 是否匿名

        Returns:
            包含 orderNo 和 initialUrl 的字典

        流程说明：
            1. 调用 /openapi/csb/ObtainCiphertext 获取签名（传明文参数，不传 orderNo）
            2. 使用返回的 sign 调用 /openapi/csb/authorizationV2（传明文参数 + sign，不传 orderNo）
            3. authorizationV2 返回最终的 initialUrl 和 orderNo（由查税宝生成）
        """
        import os

        # 使用远程签名接口获取签名
        private_key = os.getenv('CHASHUIBAO_PRIVATE_KEY', '')

        # 构建远程签名请求参数（不传 orderNo，由查税宝生成）
        sign_params = {
            'thirdPartyId': self.third_party_id,
            'privateKey': private_key,
            'taxpayerId': taxpayer_id,
            'companyName': company_name,
        }

        logger.info(f"请求查税宝签名接口: taxpayerId={taxpayer_id}, companyName={company_name}")

        # 获取远程签名（使用 POST 方法，参数通过 query string 传递）
        sign_response = await self._request('POST', '/openapi/csb/ObtainCiphertext', params=sign_params)

        code = sign_response.get('code')
        if code not in ('0', 0):
            error_msg = sign_response.get('message', '获取签名失败')
            logger.error(f"获取远程签名失败: {error_msg}")
            raise Exception(error_msg)

        # 从响应中提取 sign
        response_data = sign_response.get('data', {})
        sign = response_data.get('sign', '')

        if not sign:
            raise Exception("服务端返回的签名为空")

        logger.info(f"查税宝返回签名: sign={sign[:20]}...")

        # 构建授权链接请求参数（不传 orderNo，由查税宝生成）
        params = {
            'thirdPartyId': self.third_party_id,
            'taxpayerId': taxpayer_id,
            'companyName': company_name,
            'reportType': report_type,
            'cburl': cburl,
            'sign': sign,
        }

        # 添加可选参数
        if begin_date:
            params['beginDate'] = begin_date
        if over_date:
            params['overDate'] = over_date
        if report_logo:
            params['reportLogo'] = report_logo
        if watermark:
            params['watermark'] = watermark
        if cover_url:
            params['coverUrl'] = cover_url
        if is_anonymity is not None:
            params['isAnonymity'] = is_anonymity

        logger.info(f"请求获取发票穿透授权链接: company_name={company_name}")

        # 发送请求
        response = await self._request('GET', '/openapi/csb/authorizationV2', params=params)

        # 检查响应（code 可能是数字 0 或字符串 '0'）
        if response.get('code') in ('0', 0):
            logger.info(f"获取授权链接成功: {response.get('data', {}).get('orderNo')}")
            return response.get('data', {})
        else:
            error_msg = response.get('message', '获取授权链接失败')
            logger.error(f"获取授权链接失败: {error_msg}")
            raise Exception(error_msg)

    async def get_report_data(
        self,
        taxpayer_id: str,
        company_name: str,
        order_no: str,
        data_type: Optional[int] = None
    ) -> Dict[str, Any]:
        """获取报告数据

        Args:
            taxpayer_id: 纳税人识别号（明文）
            company_name: 企业名称（明文）
            order_no: 订单号
            data_type: 数据类型（1-数据，2-报告url）

        Returns:
            报告数据

        流程说明：
            1. 调用 /openapi/csb/ObtainCiphertext 获取签名（传明文参数）
            2. 使用返回的 sign 调用 /openapi/csb/openInvoiceReportV2（传明文参数 + sign）
        """
        # 使用远程签名接口获取签名
        sign = await self._obtain_remote_signature(taxpayer_id, company_name, order_no)

        # 构建请求参数
        params = {
            'thirdPartyId': self.third_party_id,
            'taxpayerId': taxpayer_id,
            'companyName': company_name,
            'orderNo': order_no,
            'sign': sign,
        }

        # 添加可选参数
        if data_type is not None:
            params['dataType'] = data_type

        logger.info(f"请求获取发票穿透报告数据: order_no={order_no}")
        logger.debug(f"请求参数: {params}")

        # 发送请求
        url = f"{self.base_url}/openapi/csb/openInvoiceReportV2"
        logger.debug(f"完整URL: {url}")

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.get(url, params=params)
                logger.debug(f"响应状态码: {response.status_code}")
                logger.debug(f"响应内容: {response.text}")
                response.raise_for_status()
                result = response.json()
            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP 请求失败: {e.response.status_code} - {e.response.text}")
                raise Exception(f"发票穿透 API 请求失败: {e.response.status_code} - {e.response.text}")
            except httpx.RequestError as e:
                logger.error(f"HTTP 请求异常: {e}")
                raise Exception(f"发票穿透 API 请求异常: {str(e)}")

        # 检查响应（code 可能是数字 0 或字符串 '0'）
        if result.get('code') in ('0', 0):
            logger.info(f"获取报告数据成功: {order_no}")
            return result.get('data', {})
        else:
            error_msg = result.get('message', '获取报告数据失败')
            logger.error(f"获取报告数据失败: {error_msg}")
            raise Exception(error_msg)

    async def _obtain_remote_signature(
        self,
        taxpayer_id: str,
        company_name: str,
        order_no: Optional[str] = None
    ) -> str:
        """获取远程签名（使用 /openapi/csb/ObtainCiphertext 接口）

        调用服务端签名接口获取加密后的签名字符串。

        注意：此接口使用 POST 请求，参数放在 URL Query 中。
        只有当 orderNo 有值时才会传递给鉴权接口，否则不传。

        Args:
            taxpayer_id: 纳税人识别号
            company_name: 企业名称
            order_no: 订单号（可选，只有有值时才会传递）

        Returns:
            签名字符串
        """
        import os

        # 获取原始私钥（用于传给服务端）
        private_key = os.getenv('CHASHUIBAO_PRIVATE_KEY', '')

        # 构建请求参数（将放在 URL Query 中）
        # thirdPartyId 和 privateKey 必须始终传递
        # orderNo 只有在有值时才传递
        params = {
            'thirdPartyId': self.third_party_id,
            'privateKey': private_key,
            'taxpayerId': taxpayer_id,
            'companyName': company_name,
        }

        # 只有当 orderNo 有值时才添加到参数中
        if order_no:
            params['orderNo'] = order_no

        logger.debug(f"请求远程签名: order_no={order_no}")

        # 使用 POST 方法，参数放在 URL Query 中
        url = f"{self.base_url}/openapi/csb/ObtainCiphertext"

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.post(url, params=params)
                response.raise_for_status()
                result = response.json()
            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP 请求失败: {e.response.status_code} - {e.response.text}")
                raise Exception(f"远程签名 API 请求失败: {e.response.status_code}")
            except httpx.RequestError as e:
                logger.error(f"HTTP 请求异常: {e}")
                raise Exception(f"远程签名 API 请求异常: {str(e)}")

        # 打印响应用于调试
        logger.info(f"远程签名响应: code={result.get('code')}, message={result.get('message')}, data={result.get('data')}")
        logger.debug(f"完整响应: {result}")

        # 检查响应
        code = result.get('code')
        if code == '0' or code == 0:
            # 尝试多种方式获取签名
            sign = None

            # 方式1: data.sign
            if result.get('data'):
                sign = result.get('data', {}).get('sign')

            # 方式2: 直接在根级别
            if not sign:
                sign = result.get('sign')

            if sign:
                logger.info(f"远程签名获取成功")
                return sign
            else:
                logger.warning(f"服务端返回成功但签名为空，完整响应: {result}")
                raise Exception("服务端返回的签名为空")
        else:
            error_msg = result.get('message', '获取远程签名失败')
            raise Exception(f"服务端返回错误: code={code}, message={error_msg}")


# 创建全局服务实例
invoice_penetration_service = InvoicePenetrationService()
