"""基于 Unstructured 的 DOC 文件读取器

使用 Unstructured 库解析 Microsoft Word 97-2003 格式 (.doc)
这是最简单、最可靠的 DOC 解析方案，无需系统安装 Microsoft Word

支持的文档格式：
- DOC (Microsoft Word 97-2003)
- DOCX (Microsoft Word 2007+)
- PDF、HTML、图片等多种格式

依赖：
- pip install "unstructured[local-inference]" python-docx2txt
"""

import io
import os
import psutil
from pathlib import Path
from typing import List, Union, Optional

from agno.knowledge.document import Document
from agno.knowledge.reader.base import Reader as BaseReader


def kill_stuck_libreoffice_processes():
    """清理卡住的 LibreOffice 进程

    Returns:
        清理的进程数量
    """
    count = 0
    try:
        for proc in psutil.process_iter(['pid', 'name', 'create_time']):
            try:
                process_name = proc.info['name'].lower()
                # 查找 soffice.exe 或 libreoffice 进程
                if 'soffice' in process_name or 'libreoffice' in process_name:
                    # 检查进程运行时间（超过 120 秒视为卡住）
                    create_time = proc.info['create_time']
                    if create_time:
                        import time
                        runtime = time.time() - create_time
                        if runtime > 120:  # 2分钟
                            print(f"  [清理] 发现卡住的 LibreOffice 进程 (PID={proc.info['pid']}, 运行时间={int(runtime)}秒)，正在终止...")
                            proc.terminate()
                            count += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except Exception as e:
        print(f"  [警告] 清理进程时出错: {e}")
    return count


class DocReader(BaseReader):
    """基于 Unstructured 的 DOC 文件读取器"""

    def __init__(self, chunking_strategy=None, **kwargs):
        """初始化 DOC 读取器

        Args:
            chunking_strategy: 分块策略（兼容agno接口）
        """
        super().__init__(chunking_strategy=chunking_strategy, **kwargs)

        # 延迟导入 Unstructured（避免启动时依赖检查失败）
        self.unstructured_available = False
        self._check_unstructured()

    def _check_unstructured(self):
        """检查 Unstructured 是否可用"""
        try:
            from unstructured.partition.doc import partition_doc
            self.partition_doc = partition_doc
            self.unstructured_available = True
        except ImportError:
            self.unstructured_available = False
            print("⚠️  Unstructured 未安装，请运行: pip install 'unstructured[local-inference]' python-docx2txt")

    def read(
        self,
        doc: Union[str, Path, io.BytesIO],
        name: Optional[str] = None,
    ) -> List[Document]:
        """读取 DOC 文件

        Args:
            doc: DOC 文件路径、Path 对象或字节流
            name: 文档名称（可选）

        Returns:
            文档列表
        """
        if not self.unstructured_available:
            raise ImportError(
                "Unstructured 未安装，请运行以下命令安装:\n"
                "pip install 'unstructured[local-inference]' python-docx2txt"
            )

        # 准备文件路径
        if isinstance(doc, (str, Path)):
            doc_path = str(doc)
            if not os.path.exists(doc_path):
                raise FileNotFoundError(f"DOC 文件不存在: {doc_path}")

            file_size = os.path.getsize(doc_path)
            if file_size == 0:
                raise ValueError(f"DOC 文件为空（0字节）: {doc_path}")

            print(f"  [Unstructured] 文件路径: {doc_path}, 大小: {file_size} 字节")
            return self._read_with_unstructured(doc_path, name)
        else:
            # 字节流 - 需要先保存为临时文件
            content = doc.read()
            if not content or len(content) == 0:
                raise ValueError(f"DOC 字节流为空")

            print(f"  [Unstructured] 字节流大小: {len(content)} 字节")

            # 创建临时文件
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False, suffix=".doc") as tmp:
                tmp.write(content)
                temp_path = tmp.name

            try:
                return self._read_with_unstructured(temp_path, name)
            finally:
                # 清理临时文件
                if os.path.exists(temp_path):
                    try:
                        os.unlink(temp_path)
                    except:
                        pass

    def _read_with_unstructured(
        self,
        file_path: str,
        name: Optional[str] = None,
    ) -> List[Document]:
        """使用 Unstructured 解析 DOC 文件

        Args:
            file_path: 文件路径
            name: 文档名称

        Returns:
            文档列表
        """
        try:
            # 临时添加 LibreOffice 到 PATH（Windows）
            import os
            libreoffice_paths = [
                r"C:\Program Files\LibreOffice\program",
                r"C:\Program Files (x86)\LibreOffice\program",
            ]

            # 找到存在的 LibreOffice 路径
            soffice_path = None
            for path in libreoffice_paths:
                if os.path.exists(os.path.join(path, "soffice.exe")):
                    soffice_path = path
                    break

            # 临时修改 PATH 环境变量
            original_path = os.environ.get('PATH', '')
            if soffice_path:
                os.environ['PATH'] = f"{soffice_path}{os.pathsep}{original_path}"
                print(f"  [Unstructured] 已将 LibreOffice 添加到 PATH: {soffice_path}")

            try:
                # 使用 Unstructured 解析文档（带超时机制）
                try:
                    # 使用多进程添加超时机制（防止 LibreOffice 卡死）
                    from multiprocessing import Process, Queue
                    import time

                    # 创建进程间通信的队列
                    result_queue = Queue()

                    def partition_with_timeout():
                        """在子进程中执行 partition_doc"""
                        try:
                            elements = self.partition_doc(
                                filename=file_path,
                                mode="elements",  # 按元素解析（标题、段落、列表等）
                                extract_tables_in_html=False,  # 不提取表格中的HTML
                            )
                            result_queue.put(('success', elements))
                        except Exception as e:
                            result_queue.put(('error', e))

                    # 启动子进程
                    process = Process(target=partition_with_timeout)
                    process.start()

                    # 等待最多 60 秒
                    process.join(timeout=60)

                    if process.is_alive():
                        # 超时，强制终止进程
                        print(f"  ⚠️  LibreOffice 处理超时（>60秒），强制终止")
                        process.terminate()
                        process.join(timeout=5)  # 等待 5 秒让进程清理
                        if process.is_alive():
                            process.kill()  # 如果还不退出，强制杀死

                        # 清理可能卡住的 LibreOffice 子进程
                        killed = kill_stuck_libreoffice_processes()
                        if killed > 0:
                            print(f"  [清理] 已清理 {killed} 个卡住的 LibreOffice 进程")

                        raise TimeoutError(f"LibreOffice 处理文档超时（60秒）")

                    # 检查结果
                    if not result_queue.empty():
                        status, result = result_queue.get()
                        if status == 'error':
                            raise result
                        elements = result
                    else:
                        # 进程已完成但没有结果（可能被异常终止）
                        raise Exception("LibreOffice 进程异常终止，未返回结果")
                except Exception as parse_error:
                    # 捕获 LibreOffice 转换失败的情况
                    error_msg = str(parse_error).lower()
                    print(f"  ⚠️  Unstructured 解析异常: {error_msg[:100]}...")

                    # 检查是否是 LibreOffice 转换失败或文件不存在错误
                    is_conversion_error = (
                        'soffice failed' in error_msg or
                        'no such file or directory' in error_msg or
                        'cannot find' in error_msg or
                        'file not found' in error_msg or
                        'docx' in error_msg and '.doc' in file_path
                    )

                    if is_conversion_error:
                        print(f"  ⚠️  检测到 LibreOffice 转换失败，尝试使用备用方法")

                        # 尝试使用 docx2txt 直接读取原始 .doc
                        fallback_success = False
                        try:
                            from docx2txt import process
                            import io
                            import sys

                            # 捕获 stdout，因为 process() 直接打印到控制台
                            old_stdout = sys.stdout
                            sys.stdout = io.StringIO()

                            try:
                                process(file_path)
                                text_content = sys.stdout.getvalue()
                            finally:
                                sys.stdout = old_stdout

                            if text_content and text_content.strip():
                                elements = [type('Element', (), {'text': text_content})]
                                print(f"  ✅ 使用 docx2txt 成功读取文档 ({len(text_content)} 字符)")
                                fallback_success = True
                            else:
                                print(f"  ⚠️  docx2txt 读取内容为空")

                        except ImportError:
                            print(f"  ⚠️  docx2txt 未安装")
                        except Exception as docx2txt_error:
                            print(f"  ⚠️  docx2txt 读取失败: {str(docx2txt_error)[:100]}")

                        # 如果 docx2txt 失败，尝试 olefile
                        if not fallback_success:
                            try:
                                import olefile
                                import io

                                print(f"  ⚠️  尝试使用 olefile 读取")
                                if olefile.isOleFile(file_path):
                                    ole = olefile.OleFileIO(file_path)

                                    # 尝试读取 WordDocument 流
                                    if ole.exists('WordDocument'):
                                        # 尝试读取文本（简化版本）
                                        data = ole.openstream('WordDocument').read()
                                        # 这是一个非常简化的提取，实际 .doc 解析很复杂
                                        # 我们这里尝试至少提取一些可读文本
                                        try:
                                            # 尝试使用 antiword 库
                                            import subprocess
                                            result = subprocess.run(['antiword', file_path],
                                                                  capture_output=True, text=True, timeout=30)
                                            if result.returncode == 0 and result.stdout:
                                                elements = [type('Element', (), {'text': result.stdout})]
                                                print(f"  ✅ 使用 antiword 成功读取文档 ({len(result.stdout)} 字符)")
                                                fallback_success = True
                                        except:
                                            pass

                                    ole.close()

                            except ImportError:
                                print(f"  ⚠️  olefile 未安装")
                            except Exception as ole_error:
                                print(f"  ⚠️  olefile 读取失败: {str(ole_error)[:100]}")

                        # 如果所有方法都失败，返回空列表而不是抛出异常
                        if not fallback_success:
                            print(f"  ❌ 所有备用方法均失败，跳过此文档")
                            elements = []
                    else:
                        # 不是转换错误，直接抛出原始异常
                        raise
            finally:
                # 恢复原始 PATH
                if soffice_path:
                    os.environ['PATH'] = original_path

            if not elements:
                print(f"  ⚠️  Unstructured 未能提取到内容")
                return []

            # 将所有元素合并为一个文档
            import re
            content_parts = []
            for element in elements:
                text = str(element).strip()
                if text:
                    # 第一步：移除所有 HTML 标签（包括属性）
                    # 移除完整的 HTML 标签：<tag 属性="value">内容</tag>
                    text = re.sub(r'<[^>]+>', '', text)

                    # 第二步：移除 MIME multipart 边界标记
                    text = re.sub(r'-{2,}NEXT\.ITEM-BOUNDARY-*', '', text)

                    # 第三步：移除 CSS 样式块和属性
                    text = re.sub(r'\{[^}]*\}', '', text)
                    text = re.sub(r'[a-z]+\s*:\s*[^;]+;', '', text)

                    # 第四步：移除 MIME 头部信息
                    text = re.sub(r'Content-[^\n]+', '', text)
                    text = re.sub(r'Mime-Version:[^\n]+', '', text)

                    # 第五步：移除 Base64 编码数据（长串的字母数字）
                    text = re.sub(r'[A-Za-z0-9+/]{80,}={0,2}', '', text)

                    # 第六步：移除网页 UI 元素
                    text = re.sub(r'【打印】.*?纠错或建议', '', text)
                    text = re.sub(r'分享到：.*?朋友圈', '', text)
                    text = re.sub(r'已推送.*?订阅更多', '', text)
                    text = re.sub(r'全文废止.*?成文日期：', '', text)
                    text = re.sub(r'阅读量：\d+次', '', text)
                    text = re.sub(r'字体：【大】【中】【小】', '', text)
                    text = re.sub(r'微信扫一扫：.*', '', text)
                    text = re.sub(r'分享扫一扫.*', '', text)
                    text = re.sub(r'扫一扫在手机打开当前页', '', text)
                    text = re.sub(r"\$\('#share-1'\)\.share\(\);", '', text)

                    # 第七步：移除剩余的英文乱码和孤立单词
                    # 移除包含大量英文的行（>50% 英文字符）
                    lines = text.split('\n')
                    cleaned_lines = []
                    for line in lines:
                        line = line.strip()
                        if line:
                            # 计算中文字符比例
                            chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', line))
                            total_chars = len(line)
                            if total_chars > 0 and chinese_chars / total_chars < 0.3:
                                # 英文占比超过 70%，可能是网页 UI 元素，跳过
                                continue
                            # 移除纯英文行或以英文为主的行
                            if re.match(r'^[a-zA-Z\s\(\)\.\{\}\[\]\'\"]*$', line):
                                continue
                            cleaned_lines.append(line)
                    text = '\n'.join(cleaned_lines)

                    # 第八步：最终清理
                    # 将多个空格和换行合并
                    text = re.sub(r'\s+', ' ', text)
                    text = text.strip()

                    # 移除残留的 HTML 标签和属性名
                    text = re.sub(r'span|p|div|h3|h4|hl|img|a|strong|em', '', text)
                    text = re.sub(r'\.(?![\u4e00-\u9fff])\w+', '', text)

                    if text and len(text) > 10:  # 过滤掉过短的片段
                        content_parts.append(text)

            full_content = "\n\n".join(content_parts)

            if not full_content.strip():
                print(f"  ⚠️  提取的内容为空")
                return []

            # 构建元数据
            meta_data = {
                "source": name or file_path,
                "method": "unstructured",
                "num_elements": len(elements),
            }

            # 添加文件名元数据
            if name:
                meta_data["filename"] = name

            # 创建文档
            document = Document(
                content=full_content.strip(),
                name=name or file_path,
                meta_data=meta_data,
            )

            # 应用分块策略
            if self.chunking_strategy:
                try:
                    chunked_docs = self.chunking_strategy.chunk(document)
                    print(f"  ✅ Unstructured 成功提取文档，已分块为 {len(chunked_docs)} 个部分")
                    return chunked_docs
                except Exception as e:
                    print(f"  ⚠️  分块失败，使用原始文档: {e}")
                    return [document]
            else:
                print(f"  ✅ Unstructured 成功提取文档，共 {len(full_content)} 个字符")
                return [document]

        except Exception as e:
            print(f"  ❌ Unstructured 解析失败: {str(e)}")
            raise


def create_doc_reader(chunking_strategy=None) -> DocReader:
    """
    创建 DOC Reader 实例的工厂函数

    Args:
        chunking_strategy: 分块策略

    Returns:
        DocReader 实例
    """
    return DocReader(chunking_strategy=chunking_strategy)
