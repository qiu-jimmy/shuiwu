"""
会员信息缓存服务
用于缓存会员权益信息，减少数据库查询，提高权限检查性能
"""
import time
import json
from typing import Dict, Any, Optional
from threading import Lock


class MemberCache:
    """会员信息缓存（基于内存）"""

    def __init__(self):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._timestamps: Dict[str, float] = {}
        self._lock = Lock()

        # 缓存配置
        self.MEMBER_INFO_TTL = 300  # 会员信息缓存5分钟
        self.MEMBER_STATS_TTL = 60  # 使用统计缓存1分钟
        self.PRIVILEGE_CHECK_TTL = 60  # 权限检查缓存1分钟

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """获取缓存"""
        with self._lock:
            if key not in self._cache:
                return None

            # 检查是否过期
            timestamp = self._timestamps.get(key, 0)
            ttl = self._get_ttl_for_key(key)

            if time.time() - timestamp > ttl:
                # 过期，删除缓存
                del self._cache[key]
                del self._timestamps[key]
                return None

            return self._cache[key].copy()

    def set(self, key: str, value: Dict[str, Any]) -> None:
        """设置缓存"""
        with self._lock:
            self._cache[key] = value.copy()
            self._timestamps[key] = time.time()

    def delete(self, key: str) -> None:
        """删除缓存"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
            if key in self._timestamps:
                del self._timestamps[key]

    def clear_user_cache(self, user_id: str) -> None:
        """清除用户相关所有缓存"""
        with self._lock:
            keys_to_delete = [
                key for key in self._cache.keys()
                if key.startswith(f"member_info:{user_id}") or
                   key.startswith(f"member_stats:{user_id}") or
                   key.startswith(f"privilege_check:{user_id}")
            ]
            for key in keys_to_delete:
                del self._cache[key]
                del self._timestamps[key]

    def clear_all(self) -> None:
        """清空所有缓存"""
        with self._lock:
            self._cache.clear()
            self._timestamps.clear()

    def _get_ttl_for_key(self, key: str) -> int:
        """根据key类型返回TTL"""
        if key.startswith("member_info:"):
            return self.MEMBER_INFO_TTL
        elif key.startswith("member_stats:"):
            return self.MEMBER_STATS_TTL
        elif key.startswith("privilege_check:"):
            return self.PRIVILEGE_CHECK_TTL
        return 60  # 默认1分钟

    # ==================== 便捷方法 ====================

    def get_member_info(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取会员信息缓存"""
        return self.get(f"member_info:{user_id}")

    def set_member_info(self, user_id: str, info: Dict[str, Any]) -> None:
        """设置会员信息缓存"""
        self.set(f"member_info:{user_id}", info)

    def get_member_stats(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取会员统计缓存"""
        return self.get(f"member_stats:{user_id}")

    def set_member_stats(self, user_id: str, stats: Dict[str, Any]) -> None:
        """设置会员统计缓存"""
        self.set(f"member_stats:{user_id}", stats)

    def get_privilege_check(self, user_id: str, privilege_type: str) -> Optional[Dict[str, Any]]:
        """获取权限检查缓存"""
        return self.get(f"privilege_check:{user_id}:{privilege_type}")

    def set_privilege_check(self, user_id: str, privilege_type: str, result: Dict[str, Any]) -> None:
        """设置权限检查缓存"""
        self.set(f"privilege_check:{user_id}:{privilege_type}", result)


# 全局实例
member_cache = MemberCache()


# ==================== 缓存装饰器 ====================

def cached_member_info(func):
    """会员信息缓存装饰器"""
    def wrapper(user_id: str, *args, **kwargs):
        # 尝试从缓存获取
        cached = member_cache.get_member_info(user_id)
        if cached is not None:
            return {"success": True, "data": cached, "from_cache": True}

        # 调用原函数
        result = func(user_id, *args, **kwargs)

        # 如果成功，写入缓存
        if result.get("success"):
            member_cache.set_member_info(user_id, result)

        return result
    return wrapper


def cached_member_stats(func):
    """会员统计缓存装饰器"""
    def wrapper(user_id: str, *args, **kwargs):
        # 尝试从缓存获取
        cached = member_cache.get_member_stats(user_id)
        if cached is not None:
            return {"success": True, **cached, "from_cache": True}

        # 调用原函数
        result = func(user_id, *args, **kwargs)

        # 如果成功，写入缓存
        if result.get("success"):
            member_cache.set_member_stats(user_id, result)

        return result
    return wrapper


def cached_privilege_check(func):
    """权限检查缓存装饰器"""
    def wrapper(user_id: str, privilege_type: str, *args, **kwargs):
        # 尝试从缓存获取
        cached = member_cache.get_privilege_check(user_id, privilege_type)
        if cached is not None:
            return cached

        # 调用原函数
        result = func(user_id, privilege_type, *args, **kwargs)

        # 如果成功且权限被拒绝，缓存结果
        # 权限通过的结果不缓存，因为可能随时变化
        if result.get("success") and not result.get("has_privilege"):
            member_cache.set_privilege_check(user_id, privilege_type, result)

        return result
    return wrapper
