create view v_user_member_info
            (user_id, nickname, member_level, member_expire_at, user_type, status, package_name, max_daily_chats,
             max_kb_count, max_file_storage_mb)
as
SELECT u.user_id,
       u.nickname,
       u.member_level,
       u.member_expire_at,
       u.user_type,
       u.status,
       mp.name AS package_name,
       mp.max_daily_chats,
       mp.max_kb_count,
       mp.max_file_storage_mb
FROM users u
         LEFT JOIN member_packages mp ON u.member_level::text = mp.package_id::text;

comment on view v_user_member_info is '用户会员信息视图';

alter table v_user_member_info
    owner to postgres;

