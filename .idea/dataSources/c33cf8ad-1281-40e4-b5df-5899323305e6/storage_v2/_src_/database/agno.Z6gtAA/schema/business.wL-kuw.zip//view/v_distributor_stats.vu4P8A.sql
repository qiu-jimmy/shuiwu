create view v_distributor_stats
            (user_id, distributor_code, distributor_level, total_children_count, total_commission, available_commission,
             nickname, phone)
as
SELECT d.user_id,
       d.distributor_code,
       d.distributor_level,
       d.total_children_count,
       d.total_commission,
       d.available_commission,
       u.nickname,
       u.phone
FROM distributors d
         JOIN users u ON d.user_id::text = u.user_id::text;

comment on view v_distributor_stats is '分销统计视图';

alter table v_distributor_stats
    owner to postgres;

